package hr.fer.oop.lab3;

public interface ManageableTeam {
    boolean addPlayerToStartingEleven(FootballPlayer player);

    double calculateRating();

    void clearStartingEleven();

    Formation getFormation();

    SimpleFootballCollection getRegisteredPlayers();

    SimpleFootballCollection getStartingEleven();

    boolean isPlayerRegistered(FootballPlayer player);

    boolean registerPlayer(FootballPlayer player);

    void setFormation(Formation formation);

}