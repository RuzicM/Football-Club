package hr.fer.oop.lab3;

public enum PlayingPosition {
    FW,MF,DF,GK
}
