package hr.fer.oop.lab3;

public class Coach extends Person implements Manager {
    private int coachingSkill = 50;
    Formation favoriteFormation = Formation.F442;
    ManageableTeam manageableTeam;

    public Coach() {

    }

    public Coach(String name, String country, int emotion, int coachingSkill, Formation favoriteFormation) {
        super(name, country, emotion);
        this.coachingSkill = coachingSkill;
        this.favoriteFormation = favoriteFormation;
    }

    public int getCoachingSkill() {
        return coachingSkill;
    }

    public void setCoachingSkill(int coachingSkill) {
        if (coachingSkill < 0 || coachingSkill > 100) {
            throw new IllegalArgumentException(("Wrong input try again (0-100)"));
        }
        this.coachingSkill = coachingSkill;
    }

    public Formation getFavoriteFormation() {
        return favoriteFormation;
    }

    public void setFavoriteFormation(Formation favoriteFormation) {
        this.favoriteFormation = favoriteFormation;
    }


    @Override
    public void forceMyFormation() {
        manageableTeam.setFormation(favoriteFormation);
    }

    @Override
    public void pickStartingEleven() {
        int dF = 0, mF = 0, fW = 0;
        for (FootballPlayer player : manageableTeam.getRegisteredPlayers().getPlayers()) {
            if (player.getPlayingPosition() == PlayingPosition.FW && fW < manageableTeam.getFormation().FW) {
                fW++;
                manageableTeam.addPlayerToStartingEleven(player);
            } else if (player.getPlayingPosition() == PlayingPosition.DF && dF < manageableTeam.getFormation().DF) {
                dF++;
                manageableTeam.addPlayerToStartingEleven(player);
            } else if (player.getPlayingPosition() == PlayingPosition.MF && mF < manageableTeam.getFormation().MF) {
                mF++;
                manageableTeam.addPlayerToStartingEleven(player);
            }
        }
    }

    @Override
    public void setManagingTeam(ManageableTeam team) {
        this.manageableTeam = team;
    }
}
