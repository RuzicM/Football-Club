package hr.fer.oop.lab3;


public class ClubTeam extends Team {
    private int reputation = 50;

    public ClubTeam() {

    }

    public ClubTeam(String name, Formation formation, int reputation) {
        super(name, formation);
        this.reputation = reputation;
    }

    public int getReputation() {
        return reputation;
    }

    public void setReputation(int reputation) {
        if (reputation < 0 || reputation > 100) {
            throw new IllegalArgumentException("Invalid input try again(0-100)");

        }
        this.reputation = reputation;

    }

    public double calculateRating() {
        return (registeredPlayers.calculateSkillSum() * 0.7) + (registeredPlayers.calculateEmotionSum() * 0.3);
    }

    @Override
    public boolean registerPlayer(FootballPlayer player) {
        if (calculateRating() > player.getPlayingSkill()) {
            return false;
        }
        registeredPlayers.add(player);
        return true;
    }


}