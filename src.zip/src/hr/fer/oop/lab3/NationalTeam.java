package hr.fer.oop.lab3;


public class NationalTeam extends Team {
    private String country = "Noland";

    public NationalTeam() {
        super();

    }

    public NationalTeam(String name, Formation formation, String country) {
        super(name, formation);
        this.country = country;
    }

    public String getCountry() {
        return country;
    }

    public double calculateRating() {
        return (registeredPlayers.calculateEmotionSum() * 0.7) + (registeredPlayers.calculateSkillSum() * 0.3);

    }

    @Override
    public boolean registerPlayer(FootballPlayer player) {
        if (player.getCountry().equals(country)) {
            registeredPlayers.add(player);
            return true;
        }

        return false;
    }
}