package hr.fer.oop.lab3;

import java.util.Objects;

public abstract class Person {
    private String name = "Jon Doe";
    private String country = "Noland";
    private int emotion = 50;

    public Person() {

    }

    public Person(String name, String country, int emotion) {
        this.emotion = emotion;
        this.country = country;
        this.name = name;

    }

    public String getName() {
        return name;

    }

    public String getCountry() {
        return country;
    }

    public void setEmotion(int emotion) {
        if (emotion < 0 || emotion > 100) {
            throw new IllegalArgumentException("Emotion not in range try again (0-100)");
        }
        this.emotion = emotion;
    }

    public int getEmotion() {
        return emotion;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Person person = (Person) o;
        return name.equals(person.name) &&
                country.equals(person.country);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, country);
    }


}