package hr.fer.oop.lab3;

public interface Manager {
    void forceMyFormation();

    void pickStartingEleven();

    void setManagingTeam(ManageableTeam team);


}