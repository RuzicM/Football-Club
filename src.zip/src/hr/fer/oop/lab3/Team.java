package hr.fer.oop.lab3;

public abstract class Team implements ManageableTeam {
    private String name = "TeamX";
    private Formation formation = Formation.F442;
    protected SimpleFootballCollection registeredPlayers = new SimpleFootballPlayerCollectionImpl(23);
    protected SimpleFootballCollection startingEleven = new SimpleFootballPlayerCollectionImpl(11);

    public Team(String name, Formation formation) {
        this.name = name;
        this.formation = formation;
    }

    public Team() {

    }

    public String getName() {
        return name;
    }

    public Formation getFormation() {
        return formation;
    }

    @Override
    public boolean addPlayerToStartingEleven(FootballPlayer player) {
        if (isPlayerRegistered(player) && !startingEleven.contains(player)) {
            startingEleven.add(player);
            return true;
        }
        return false;
    }


    @Override
    public void clearStartingEleven() {
        startingEleven.clear();
    }

    @Override
    public SimpleFootballCollection getRegisteredPlayers() {
        return registeredPlayers;
    }

    @Override
    public SimpleFootballCollection getStartingEleven() {
        return startingEleven;
    }

    @Override
    public boolean isPlayerRegistered(FootballPlayer player) {
        return registeredPlayers.contains(player);
    }


    @Override
    public void setFormation(Formation formation) {
        this.formation = formation;
    }
}