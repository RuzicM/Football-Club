package hr.fer.oop.lab3;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        FootballPlayer player = new FootballPlayer();

        List<Integer> list = new LinkedList<>(Arrays.asList(-1, -2, -3, -4, -5, -4, -7, 5));
        int index = 0;
        while (true) {
            try {
                player.setPlayingSkill(list.get(index++));
                System.out.println("Uspješno postavljeno.");
                break;
            } catch (IllegalArgumentException ex) {
                System.out.println("KURAC");
            }
        }
    }

}
