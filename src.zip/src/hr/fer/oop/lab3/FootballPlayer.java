package hr.fer.oop.lab3;

public class FootballPlayer extends Person {
    private int playingSkill = 50;
    private PlayingPosition playingPosition = PlayingPosition.MF;

    public FootballPlayer() {

    }

    public FootballPlayer(String name, String country, int emotion, int playingSkill, PlayingPosition playingPosition) {
        super(name, country, emotion);
        this.playingSkill = playingSkill;
        this.playingPosition = playingPosition;
    }

    public void setPlayingSkill(int playingSkill) {
        if (playingSkill < 0 || playingSkill > 100) {
            throw new IllegalArgumentException("Playing skill not in range try again(0-100)");
        }
        this.playingSkill = playingSkill;
    }

    public int getPlayingSkill() {
        return playingSkill;
    }

    public void setPlayingPosition(PlayingPosition playingPosition) {
        this.playingPosition = playingPosition;
    }

    public PlayingPosition getPlayingPosition() {
        return playingPosition;
    }
}