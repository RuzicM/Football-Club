package hr.fer.oop.lab3;

public interface SimpleFootballCollection {

    boolean add(FootballPlayer player);

    int calculateEmotionSum();

    int calculateSkillSum();

    boolean contains(FootballPlayer player);

    int getMaxSize();

    FootballPlayer[] getPlayers();

    int size();

    void clear();

}