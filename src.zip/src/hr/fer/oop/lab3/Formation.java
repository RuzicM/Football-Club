package hr.fer.oop.lab3;

public enum Formation {
    F442(4, 4, 2),
    F352(3, 5, 2),
    F541(5, 4, 1);

    Formation(int DF, int MF, int FW) {
        this.DF = DF;
        this.MF = MF;
        this.FW = FW;
    }

    int MF, DF, FW;

}
