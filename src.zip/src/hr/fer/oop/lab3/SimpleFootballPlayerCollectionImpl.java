package hr.fer.oop.lab3;

import java.util.Arrays;

class SimpleFootballPlayerCollectionImpl implements SimpleFootballCollection {
    private FootballPlayer[] footballPlayers;
    private int maxSize;
    private int size = 0;

    public SimpleFootballPlayerCollectionImpl(int maxSize) {
        footballPlayers = new FootballPlayer[maxSize];
        this.maxSize = maxSize;

    }

    @Override
    public boolean add(FootballPlayer player) {
        if (size == maxSize || contains(player)) {
            return false;
        }

        footballPlayers[size++] = player;
        return true;
    }

    @Override
    public int calculateEmotionSum() {
        int emotionSum = 0;
        for (int i = 0; i < footballPlayers.length; i++) {
            emotionSum += footballPlayers[i].getEmotion();
        }
        return emotionSum;
    }

    @Override
    public int calculateSkillSum() {
        int skillSum = 0;
        for (int i = 0; i < footballPlayers.length; i++) {
            skillSum += footballPlayers[i].getPlayingSkill();
        }
        return skillSum;
    }

    @Override
    public boolean contains(FootballPlayer player) {
        for (int i = 0; i < footballPlayers.length; i++) {
            if (footballPlayers[i].equals(player)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public int getMaxSize() {
        return maxSize;
    }

    @Override
    public FootballPlayer[] getPlayers() {
        return footballPlayers;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public void clear() {
        Arrays.fill(footballPlayers, null);
        size = 0;
    }
}